#!/usr/bin/env bash
cd /data/plugins/music_service/volspotconnect2
./vollibrespot \
    -c volspotify.toml
    # --verbose
